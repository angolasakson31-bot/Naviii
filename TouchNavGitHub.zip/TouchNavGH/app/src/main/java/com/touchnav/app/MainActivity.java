package com.touchnav.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
            setupButtons();
        } catch (Exception e) {
            Toast.makeText(this, "Hata: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setupButtons() {
        Button btnOverlay = findViewById(R.id.btn_overlay);
        Button btnAccessibility = findViewById(R.id.btn_accessibility);
        Button btnToggleService = findViewById(R.id.btn_toggle_service);
        Button btnSettings = findViewById(R.id.btn_settings);

        if (btnOverlay != null) {
            btnOverlay.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnAccessibility != null) {
            btnAccessibility.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    Toast.makeText(this, "TouchNav Navigasyon'u bulun ve açın", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnToggleService != null) {
            btnToggleService.setOnClickListener(v -> {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Önce overlay iznini verin!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!isAccessibilityEnabled()) {
                    Toast.makeText(this, "Önce erişilebilirlik servisini açın!", Toast.LENGTH_SHORT).show();
                    return;
                }
                toggleService();
            });
        }

        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(this, SettingsActivity.class));
                } catch (Exception e) {
                    Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try { updateStatuses(); } catch (Exception e) { /* ignore */ }
    }

    private void updateStatuses() {
        TextView tvOverlay = findViewById(R.id.tv_overlay_status);
        TextView tvAccess = findViewById(R.id.tv_accessibility_status);
        TextView tvService = findViewById(R.id.tv_service_status);
        Button btnToggle = findViewById(R.id.btn_toggle_service);

        if (tvOverlay != null) {
            boolean ok = Settings.canDrawOverlays(this);
            tvOverlay.setText(ok ? "✓ İzin verildi" : "✗ İzin gerekli");
            tvOverlay.setTextColor(ok ? 0xFF4CAF50 : 0xFFFF5252);
        }
        if (tvAccess != null) {
            boolean ok = isAccessibilityEnabled();
            tvAccess.setText(ok ? "✓ Servis aktif" : "✗ Servis devre dışı");
            tvAccess.setTextColor(ok ? 0xFF4CAF50 : 0xFFFF5252);
        }
        if (tvService != null && btnToggle != null) {
            boolean running = AppPrefs.isServiceRunning(this);
            tvService.setText(running ? "● Çalışıyor" : "● Durduruldu");
            tvService.setTextColor(running ? 0xFF4CAF50 : 0xFF888888);
            btnToggle.setText(running ? "Durdur" : "Başlat");
        }
    }

    private void toggleService() {
        try {
            Intent serviceIntent = new Intent(this, FloatingButtonService.class);
            if (AppPrefs.isServiceRunning(this)) {
                stopService(serviceIntent);
                AppPrefs.setServiceRunning(this, false);
                Toast.makeText(this, "Durduruldu", Toast.LENGTH_SHORT).show();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "Başlatıldı! ✓", Toast.LENGTH_SHORT).show();
            }
            findViewById(R.id.btn_toggle_service).postDelayed(this::updateStatuses, 800);
        } catch (Exception e) {
            Toast.makeText(this, "Hata: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean isAccessibilityEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am == null) return false;
            List<AccessibilityServiceInfo> services =
                    am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            for (AccessibilityServiceInfo info : services) {
                if (info.getId().contains(getPackageName())) return true;
            }
        } catch (Exception e) { /* ignore */ }
        return false;
    }
}
