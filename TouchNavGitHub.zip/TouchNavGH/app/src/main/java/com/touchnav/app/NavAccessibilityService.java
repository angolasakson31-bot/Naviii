package com.touchnav.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class NavAccessibilityService extends AccessibilityService {

    private static NavAccessibilityService instance;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // We only use this service to perform global actions, no event processing needed
    }

    @Override
    public void onInterrupt() {
        // Nothing
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }

    public static boolean isRunning() {
        return instance != null;
    }

    /**
     * Execute a named action string from AppPrefs constants.
     */
    public static boolean performAction(String action) {
        if (instance == null) return false;
        switch (action) {
            case AppPrefs.ACTION_BACK:
                return instance.performGlobalAction(GLOBAL_ACTION_BACK);
            case AppPrefs.ACTION_HOME:
                return instance.performGlobalAction(GLOBAL_ACTION_HOME);
            case AppPrefs.ACTION_RECENTS:
                return instance.performGlobalAction(GLOBAL_ACTION_RECENTS);
            case AppPrefs.ACTION_NOTIFICATIONS:
                return instance.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case AppPrefs.ACTION_POWER_MENU:
                return instance.performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
            case AppPrefs.ACTION_FORWARD:
                // No direct global action for "forward", use BACK as fallback gesture-wise
                // Apps usually don't have forward; we can try the keycode via performGlobalAction
                return false;
            case AppPrefs.ACTION_NOTHING:
            default:
                return true;
        }
    }
}
